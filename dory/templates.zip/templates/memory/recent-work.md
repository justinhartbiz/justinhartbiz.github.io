# Recent Work — Last 48 Hours

> Updated by all agents (main, cron, sub-agents) after producing deliverables.
> Check this FIRST when user references recent work.

---

## [Today's Date]

### [Project Name] — [STATUS]
- **Path:** `path/to/files/`
- **What:** Brief description of what was built
- **Next:** What's remaining

---

*Updated: [timestamp]*
