# DECISIONS.md — Recent Choices

> Record significant decisions with timestamps. Helps resolve conflicts and maintain continuity.

---

## Format

```
[YYYY-MM-DD HH:MM | session] Decision made
```

---

## Recent Decisions

[none]

---

*Updated: [timestamp]*
