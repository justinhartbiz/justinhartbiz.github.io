# ACTIVE.md — Current Task

> Write the user's **exact words** here BEFORE interpreting. This is the Dory-proof pattern.

---

## Current Instruction

**User said:** [none yet]

**Interpretation:** [waiting for task]

**Status:**
- [ ] Waiting for instruction

---

*Updated: [timestamp]*
