# HOLD.md — Blocked Items

> Items here are BLOCKED. All agents must check this file before acting on anything that looks ready.

---

## Format

```
[YYYY-MM-DD HH:MM | session] Item — reason blocked
```

---

## Currently Blocked

[none]

---

*Updated: [timestamp]*
